package com.comcastad.rest.server;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.comcastad.rest.data.model.AddDetails;

@Path("/ad")
public class RestServer {

	@GET
	@Path("/{param}")
	@Produces(MediaType.APPLICATION_JSON)
	public AddDetails getaddDetails(@PathParam("param") int partnerId){
		//create a student object and set some data
		AddDetails addDetails = null;
		
		
			
		
		if (partnerId==1234){
		 addDetails = new AddDetails();
		addDetails.setAddDetails("This is Comcast Add");
		addDetails.setDuration("2H");
		addDetails.setPartnerId(1234);
		
		}
		return addDetails;
			}
	
	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addRecord(AddDetails addDetails){
		String result = "Record entered: "+ addDetails;
		return Response.status(201).entity(result).build();
	}
}
